# Opening an Issue
If you find any problem with the temporal annotation tool you are free to open a new issue. Please check before the [README file](README.md) and other issues to see if your issue is already solved. 

## Feature Request

### Is your feature request related to a problem? Please describe.
A clear and concise description of what the problem is. Ex. I have an issue when [...]

## Describe the solution you'd like
A clear and concise description of what you want to happen. Add any considered drawbacks.

## Describe alternatives you've considered
A clear and concise description of any alternative solutions or features you've considered.

## Teachability, Documentation, Adoption, Migration Strategy
If you can, explain how users will be able to use this and possibly write out a version the docs.
Maybe a screenshot or design?




